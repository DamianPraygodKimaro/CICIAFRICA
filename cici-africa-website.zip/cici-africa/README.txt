CICI AFRICA WEBSITE — FILE STRUCTURE
======================================

cici-africa/
├── index.html          ← Home page
├── services.html       ← Services + Booking form
├── culture.html        ← Culture Feed (Popcorn, Jams, Podcasts, Docs)
├── talents.html        ← Talents showcase + Book/Join forms
├── events.html         ← Past events + Upcoming + Countdown
├── assets/
│   ├── css/
│   │   └── style.css   ← ALL shared styles + responsive + animations
│   ├── js/
│   │   └── main.js     ← ALL shared JS: tabs, scroll reveal, forms, toast
│   └── images/         ← Put your team photos here with these names:
│       ├── antoinette.jpg
│       ├── isack.jpg
│       ├── allen.jpg
│       └── lisa.jpg

HOW TO ADD IMAGES
-----------------
Place your team photos in assets/images/ with the filenames above.
The site uses graceful fallbacks if images are missing.

HOW TO CUSTOMIZE
-----------------
- Colors  → Edit :root variables in style.css (top of file)
- Fonts   → Change @import in style.css and font-family variables
- Content → Edit directly in each HTML file
- New JS  → Add to main.js or create a new file and link in the HTML

SOCIAL LINKS
-----------------
Search for "ciciafrica_creatives" across all HTML files to update
social media links to the correct URLs.

